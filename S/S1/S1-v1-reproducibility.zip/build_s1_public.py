"""Render the public paper from its manuscript and actual experiment records."""
from pathlib import Path
import re,html,json,math
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,KeepTogether,XPreformatted
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor,white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import Drawing,Rect,String,Line,Polygon
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/pdf/Zawwar-Sami-S1-Temporal-Repair-Dependencies-v1.pdf'
for name,file in [('Body','DejaVuSerif.ttf'),('Bold','DejaVuSerif-Bold.ttf'),('Sans','DejaVuSans.ttf'),('SansBold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
 pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+file))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Body',boldItalic='Bold')
C=HexColor('#871d30');INK=HexColor('#19242c');PALE=HexColor('#f0f3f5');W=A4[0]-100
styles={
'body':ParagraphStyle('body',fontName='Body',fontSize=9.6,leading=14.3,spaceAfter=7.5,textColor=INK,allowWidows=0,allowOrphans=0),
'h1':ParagraphStyle('h1',fontName='SansBold',fontSize=25,leading=30,spaceAfter=11,textColor=C),
'subtitle':ParagraphStyle('subtitle',fontName='Sans',fontSize=15,leading=21,spaceAfter=16,textColor=INK),
'h2':ParagraphStyle('h2',fontName='SansBold',fontSize=12.5,leading=17,spaceBefore=14,spaceAfter=8,keepWithNext=True,textColor=C),
'h3':ParagraphStyle('h3',fontName='SansBold',fontSize=10.5,leading=15,spaceBefore=9,spaceAfter=7,keepWithNext=True,textColor=INK),
'cell':ParagraphStyle('cell',fontName='Sans',fontSize=7.9,leading=11.3,textColor=INK),
'cellhead':ParagraphStyle('cellhead',fontName='SansBold',fontSize=7.9,leading=11.3,textColor=white),
'caption':ParagraphStyle('caption',fontName='Body',fontSize=8.6,leading=12.4,spaceBefore=6,spaceAfter=10,textColor=INK),
'ref':ParagraphStyle('ref',fontName='Body',fontSize=8.4,leading=12,spaceAfter=8,splitLongWords=True,textColor=INK),
'code':ParagraphStyle('code',fontName='Mono',fontSize=7.65,leading=11.2,leftIndent=9,rightIndent=9,spaceBefore=6,spaceAfter=9,backColor=PALE,borderPadding=8,textColor=INK),
}

def fmt(s):
 links=[]
 def store(m):
  links.append((m[1],m[2]));return f'LINKTOKEN{len(links)-1}END'
 s=re.sub(r'\[([^\]]+)\]\((https?://[^\s)]+)\)',store,s)
 s=html.escape(s)
 s=re.sub(r'`([^`]+)`',r'<font name="Mono" size="8.4">\1</font>',s)
 s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
 for i,(label,url) in enumerate(links):s=s.replace(f'LINKTOKEN{i}END',f'<link href="{html.escape(url,quote=True)}" color="#234d77">{html.escape(label)}</link>')
 return s

def arrow(d,x1,y1,x2,y2,dash=False):
 l=Line(x1,y1,x2,y2,strokeColor=INK,strokeWidth=.9)
 if dash:l.strokeDashArray=[3,2]
 d.add(l);a=math.atan2(y2-y1,x2-x1)
 d.add(Polygon([x2,y2,x2-5*math.cos(a-.5),y2-5*math.sin(a-.5),x2-5*math.cos(a+.5),y2-5*math.sin(a+.5)],fillColor=INK,strokeColor=INK))

def service_figure():
 d=Drawing(W,210)
 def box(x,y,w,title,sub):
  d.add(Rect(x,y,w,42,rx=4,ry=4,fillColor=PALE,strokeColor=C,strokeWidth=.8))
  d.add(String(x+w/2,y+26,title,fontName='SansBold',fontSize=9,fillColor=INK,textAnchor='middle'))
  d.add(String(x+w/2,y+11,sub,fontName='Sans',fontSize=7.4,fillColor=INK,textAnchor='middle'))
 box(0,90,126,'Controller','repair and renewal schedule')
 box(184,153,135,'Issuer service','renewal enabled / restored')
 box(345,90,148,'Resource service','principal + session tables')
 box(184,15,135,'Observer process','HTTP-only canary readback')
 arrow(d,126,122,184,169,True);arrow(d,126,110,345,110,True)
 arrow(d,319,168,410,132);d.add(String(360,171,'provision',fontName='Sans',fontSize=7.5,fillColor=C,textAnchor='middle'))
 arrow(d,319,36,393,90);d.add(String(379,51,'GET /data',fontName='Sans',fontSize=7.5,fillColor=C,textAnchor='middle'))
 arrow(d,70,90,184,37,True)
 d.add(String(5,5,'Solid: exercised service path   Dashed: scheduling / control',fontName='Sans',fontSize=7.4,fillColor=INK))
 return d

def heatmap():
 results=json.loads((ROOT/'temporal_repair/results/http_results.json').read_text())
 rows=[r for r in results['trials'] if r['repetition']==0 and not r['isolated']]
 orders=list(dict.fromkeys(tuple(r['order']) for r in rows));masks=list(dict.fromkeys(tuple(r['mask']) for r in rows))
 d=Drawing(W,230);x0=112;cw=44;rh=25;y0=180
 names={'restore-issuer':'R','disable-principals':'P','invalidate-sessions':'S'}
 for j,m in enumerate(masks):d.add(String(x0+j*cw+cw/2,213,''.join(map(str,m)),fontName='Mono',fontSize=8.3,textAnchor='middle',fillColor=INK))
 for i,o in enumerate(orders):
  y=y0-i*rh
  d.add(String(5,y+8,' > '.join(names[a] for a in o),fontName='SansBold',fontSize=9,fillColor=INK))
  for j,m in enumerate(masks):
   r=next(r for r in rows if tuple(r['order'])==o and tuple(r['mask'])==m)
   opened=r['final']=='open'
   d.add(Rect(x0+j*cw,y,cw-3,rh-3,fillColor=C if opened else PALE,strokeColor=white,strokeWidth=.4))
   d.add(String(x0+j*cw+(cw-3)/2,y+7,'OPEN' if opened else 'CLOSED',fontName='Sans',fontSize=6.5,textAnchor='middle',fillColor=white if opened else INK))
 d.add(String(5,30,'R: restore issuer   P: delete principals   S: invalidate sessions',fontName='Sans',fontSize=8,fillColor=INK))
 d.add(String(5,13,'Mask bits request renewal after repair positions 1, 2 and 3.',fontName='Sans',fontSize=8,fillColor=INK))
 return d

def build():
 story=[];lines=(ROOT/'S1_Integrated_Manuscript.md').read_text().splitlines();i=0;refs=False
 while i<len(lines):
  s=lines[i].strip()
  if not s:i+=1;continue
  if s.startswith('```'):
   code=[];i+=1
   while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i]);i+=1
   i+=1
   assert max(map(len,code),default=0)<96, 'code listing too wide'
   parts=[XPreformatted(html.escape('\n'.join(code)),styles['code'])]
   j=i
   while j<len(lines) and not lines[j].strip():j+=1
   if j<len(lines) and lines[j].startswith('Listing '):
    parts.append(Paragraph(fmt(lines[j]),styles['caption']));i=j+1
   story.append(KeepTogether(parts));continue
  if s in ('[[SERVICE_FIGURE]]','[[HEATMAP_FIGURE]]'):
   drawing=service_figure() if s=='[[SERVICE_FIGURE]]' else heatmap();i+=1
   while i<len(lines) and not lines[i].strip():i+=1
   caption=Paragraph(fmt(lines[i]),styles['caption']);i+=1
   story.append(KeepTogether([drawing,caption]));continue
  if s.startswith('|'):
   rows=[]
   while i<len(lines) and lines[i].strip().startswith('|'):
    a=[v.strip() for v in lines[i].strip().strip('|').split('|')]
    if not all(re.fullmatch(r'[:\- ]+',v) for v in a):rows.append(a)
    i+=1
   n=len(rows[0]);assert all(len(r)==n for r in rows)
   if n==5:widths=[W*.12,W*.18,W*.25,W*.22,W*.23]
   elif n==3:widths=[W*.30,W*.27,W*.43]
   else:widths=[W/n]*n
   # Graph result table: numeric columns, compact and balanced.
   if n==5 and rows[0][0]=='Nodes':widths=[W*.12,W*.19,W*.25,W*.20,W*.24]
   cells=[[Paragraph(fmt(c),styles['cellhead' if j==0 else 'cell']) for c in r] for j,r in enumerate(rows)]
   t=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
   t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),C),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('ROWBACKGROUNDS',(0,1),(-1,-1),[PALE,white])]))
   j=i
   while j<len(lines) and not lines[j].strip():j+=1
   if j<len(lines) and lines[j].startswith('Table '):
    story.append(KeepTogether([t,Paragraph(fmt(lines[j]),styles['caption'])]));i=j+1
   else:story.extend([t,Spacer(1,8)])
   continue
  if s.startswith('# '):story.append(Paragraph(fmt(s[2:]),styles['h1']));i+=1;continue
  if s.startswith('## '):
   title=s[3:];refs=title=='References';style='subtitle' if i<4 else 'h2'
   story.append(Paragraph(fmt(title),styles[style]));i+=1;continue
  if s.startswith('### '):story.append(Paragraph(fmt(s[4:]),styles['h3']));i+=1;continue
  p=[s];i+=1
  while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','```','[[')):
   p.append(lines[i].strip());i+=1
  para=Paragraph(fmt(' '.join(p)),styles['ref' if refs else 'body'])
  story.append(KeepTogether([para]) if refs else para)
 def page(c,doc):
  w,h=A4;c.setStrokeColor(C);c.setLineWidth(.7);c.line(50,h-36,w-50,h-36)
  c.setFont('Sans',7.3);c.setFillColor(C);c.drawString(50,h-27,'SECURITY & ADVERSARIAL SYSTEMS')
  c.setFont('Sans',7.1);c.setFillColor(HexColor('#5c6470'));c.drawString(50,29,'Zawwar Sami  |  Temporal Repair Dependencies  |  17 October 2026')
  c.drawRightString(w-50,29,str(doc.page))
 OUT.parent.mkdir(parents=True,exist_ok=True)
 doc=SimpleDocTemplate(str(OUT),pagesize=A4,leftMargin=50,rightMargin=50,topMargin=53,bottomMargin=49,
 title='When Revocation Does Not End Access: Temporal Repair Dependencies in Application Compromise',author='Zawwar Sami',subject='Generation-aware repair contracts and controlled HTTP experiments')
 doc.build(story,onFirstPage=page,onLaterPages=page);print(OUT)

if __name__=='__main__':build()
