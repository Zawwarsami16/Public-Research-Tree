# Incident diagnostic notes

Zawwar Sami | 16 October 2026

These extended historical walkthroughs motivate the temporal-repair study; they do not establish that its constructed repair sequences occurred at the victims. Citation numbers refer to the accompanying paper.

## 3. Equifax: reconstructing a breach across several boundaries

### 3.1 What happened, and what the records actually establish

The 2018 House staff report provides a substantially richer architecture than a one-line description of an unpatched website. It describes an ACIS environment with two web servers, two application servers, perimeter firewalls, a mounted share containing unencrypted application credentials, and access to databases beyond the application's business requirement [16, pp. 31-33, 72-79]. The platform history includes Sun/Solaris systems and an evolving consumer dispute service. Its legacy business history does not mean every software component existed in the 1970s.

Apache's S2-045 bulletin identifies CVE-2017-5638 in Jakarta multipart handling: attacker-controlled request metadata could enter exception/error-message processing and cause code execution. The historical fixes were Struts 2.3.32 and 2.5.10.1; the bulletin also describes parser changes and qualified workarounds [17]. These are historical facts, not current deployment recommendations. At the mechanism level, an input intended to describe a request acquired influence over executable interpretation.

| Stage | Documented sequence | Boundary crossed | Evidence limit |
|---|---|---|---|
| Warning and coverage | Patch public on 7 March; internal alert on 9 March; subsequent scanning missed the exposed instance [16] | Published knowledge to accountable asset remediation | Alert delivery does not prove component identification or installation |
| Initial access | GAO describes March command execution and a separate May theft incident [1] | External request to application execution | Common technique does not establish common operator |
| Retained execution | House report describes web shells on application servers [16, pp. 31-32] | One execution to repeatable access | The report is a documentary reconstruction, not a new execution here |
| Authority expansion | Accessible credentials enabled access to 48 databases beyond the three needed by ACIS [1,16] | Application trust to unrelated database authority | Exact effective grants and all network rules are not published |
| Data access and release | Queries located personal data, which was staged and transferred [16, pp. 32-33] | Database read to external disclosure | Query counts do not measure attacker skill or all attempted access |
| Detection and response | Traffic inspection resumed; suspicious activity was noticed; ACIS was taken offline [1,16] | Observation to containment | Detection time differs from initial compromise time |

The House report names approximately thirty distinct web shells, identifies file-integrity monitoring as absent on ACIS, and names Wget in its account of data transfer [16]. Those are documented details, but a complete command transcript, exact malware language, and an operator's reasoning are unavailable. Treating a familiar utility as the cause would miss the prior authority that made its use consequential.

### 3.2 Architecture, useful design choices, and their failure conditions

The service had a real purpose: consumers needed a way to submit documents and dispute credit information. Web and application tiers allowed that functionality to be presented publicly while backend business logic and data remained internal. Perimeter filtering can limit unnecessary exposure; encryption protects legitimate traffic; application credentials make unattended business operations possible. The diagnostic question is what happens when the application itself becomes an unauthorized caller.

The reported firewalls did not prevent a permitted application path from carrying an exploit. This is different from demonstrating that a network firewall's rule engine was bypassed. Once execution occurred in the application tier, credentials and database reach extended the available authority. The security boundary therefore depended on application input handling, filesystem access, database authorization, and internal communication policy working together.

The application's requirement for three databases is especially useful. It provides a source-backed functional baseline against which access to forty-eight unrelated databases can be questioned. A broad recommendation to add segmentation becomes a concrete engineering test: can the dispute service complete its documented workflow while connections to unrelated databases are denied? Business regression testing belongs alongside that security test. A control that stops the breach path by disabling required dispute processing has an availability cost that must be stated.

The later remediation recommendations include tighter data access, reduced sensitive-data retention, segmentation, integrity monitoring, richer logging, privileged-account management and improved inspection [16, pp. 85-87]. These were not all inventions prompted by hindsight; the report describes recognized concerns and work already underway. New architecture claims must therefore be measured against those existing recommendations.

### 3.3 Diagnosis: work backward without inventing a cause

Suppose the first available observation is an unusual query against an unrelated database. That supports investigation of database identity and access scope. It does not yet distinguish stolen credentials used elsewhere, an active application compromise, or authorized but anomalous administration. The next useful evidence is the effective database principal, source context, session timing, and a matching application/process history. An external request log alone cannot answer the database question.

If a suspicious server-side file is found, preserve its identity, timestamp provenance, and relation to execution before removing it. A file's existence supports a different claim from proof that it ran. A missing integrity alert is informative only if that monitor covered the relevant path and interval. If credential exposure is established, the inquiry follows each credential's scope rather than stopping at the originating host.

The reports also disagree on a material timing detail. GAO describes a certificate expired roughly ten months before the breach; the House report states nineteen months and explicitly challenges GAO's figure [1, p. 14; 16, p. 89 n. 554]. This investigation has not inspected the underlying certificate and operator logs. The defensible shared conclusion is that intended inspection was unavailable during the attack; an exact outage duration remains source-contested. A diagnostic paper should preserve that disagreement rather than average incompatible statements.

### 3.4 What could have changed the outcome?

| Proposed alternative | Intended effect | Why it might help | What it does not establish |
|---|---|---|---|
| Verify the relevant component patch before the May access | Prevent the reported entry transition | Removes the documented vulnerable mechanism | No proof that every other entry route disappears |
| Restrict the application's database identity and reach to required stores | Limit expansion | Targets the excess authority documented in the reports | Does not protect all data legitimately served by the application |
| Remove broadly readable credential material and verify replacement identities | Limit acquired authority | Reduces the ability to carry access across resource boundaries | Rotation can be undermined if a surviving authority can obtain replacements |
| Validate monitoring with a benign known event and an independent receipt | Improve detection confidence | Separates a deployed inspection device from working coverage | Monitoring alone does not block access or guarantee response |
| Reduce retained sensitive data while preserving required service | Bound potential consequence | Changes what can be disclosed after a read succeeds | Does not prevent code execution |

These are supported engineering counterfactuals and proposed tests, not measured alternative histories. Their value is that each names a specific boundary, intended outcome, and remaining route. The smallest decisive intervention depends on whether the task is pre-entry prevention, limiting an ongoing compromise, or removing authority already acquired.

## 4. Exchange: one entry weakness, several possible consequences

### 4.1 Incident and researcher evidence must remain separate

Microsoft describes March 2021 exploitation involving SSRF, post-authentication file writes, a separate deserialization issue, and observed post-exploitation tools [2]. The reported tools included ASP web shells, Procdump, 7-Zip, Exchange PowerShell mailbox export, Nishang and PowerCat. Their plausible roles concern repeated execution, credential-related collection, packaging, mailbox operations and connections respectively; the report does not put every tool on every victim. Tool choice alone does not reveal operator identity, budget or the alternatives considered. Volexity's early investigation identified mailbox theft without confirming its original backdoor hypothesis; later investigated paths included further compromise [4]. This is a campaign family with different victim histories, not one uniform four-CVE sequence.

Orange Tsai's independent research explains the frontend/backend proxy architecture: frontend handlers route requests and carry internal identity context; backend processing reconstructs context for business logic. Tsai describes a ProxyLogon chain involving CVE-2021-26855 and CVE-2021-27065, while explicitly distinguishing parts of the observed intrusion activity from the researchers' own chain [18]. That distinction prevents a laboratory route from being presented as a recovered attacker transcript.

### 4.2 Functional architecture and the diagnostic walkthrough

The engineering reconstruction has three relevant roles: an external request, an intermediary with server authority, and a backend performing sensitive operations. The same physical machine can host more than one role. Physical co-location does not erase the authorization boundary between them.

| Diagnostic stage | Question | Evidence to examine in an authorized investigation | Possible conclusion |
|---|---|---|---|
| Exposure | Which historical product, deployment and patch interval are involved? | Inventory, build history, public routing and actual update records | Susceptibility can be bounded; exploitation is not yet proved |
| Request handling | Was a backend operation reached under unexpected context? | Correlated proxy/backend logs and known coverage gaps | Supports a trust-context problem; an odd request alone may be scanning |
| Data access | Were protected mailbox operations completed? | Mailbox-access records, identity mapping, timestamps and transfer evidence | Can establish a confidentiality question without requiring an implant |
| Written state | Was code or configuration changed and used? | File provenance, process history and relevant logs | May establish a durable path; existence and execution remain distinct |
| Further authority | Were other identities or systems reached? | Credential-use and downstream records where retained | Broadens scope only where supported |
| Recovery | Which of those routes survive the intervention? | Update evidence plus independent state and identity checks | Closure must match the actual affected scope |

The response workflow already distinguishes scanning, mailbox access, web shells, and further activity [3]. S1's contribution is to connect those branches to alternative explanations and explicit intervention effects. A scanner result is a statement about the scanner's test. A confirmed mailbox read is a statement about a data operation. Combining them without their time and principal context can create a narrative that no individual record supports.

The direct-data branch matters because valuable mail can be served through legitimate backend functionality. Preventing executable file creation can interrupt a persistence route while leaving a different unauthorized data route possible. Conversely, confirming suspicious requests does not prove that a mailbox read succeeded. The test that distinguishes those explanations lies at the backend data boundary.

### 4.3 Design strengths, remaining assumptions, and alternatives

A proxy layer can centralize routing and authentication, while backend components focus on mail functions. Internal identity transport permits this division. The security assumption is that externally influenced routing and metadata cannot gain the meaning reserved for a trusted internal caller. An analyst must examine both request interpretation and the authority with which the intermediary acts.

Consider three proposed interventions. A corrected frontend trust/routing mechanism targets the initial unauthorized transition. Preventing unapproved file writes targets one persistent extension. Restricting public reach reduces access to the service but can disrupt remote use and does not by itself remove an internal or already-acquired route. These affect different path sets; there is no reason to treat their control counts as interchangeable.

A proposed architectural improvement is to test that frontend identity context and backend authorization agree for both ordinary and exceptional requests, using inert local request records rather than live exploit traffic. Another is to verify data-serving authorization independently of the absence of new executable files. Neither is a newly discovered Exchange fix, and neither has been validated against Exchange software here.

If only mailbox access is evidenced, the investigation should prioritize affected principals and disclosure scope while checking for additional state. If a web shell is evidenced, investigation expands to its possible authority and downstream effects. If only scanning is observed and logs are complete enough for that distinction, one should not automatically claim data theft. These branches produce different evidence demands without pretending that the public reports reveal every adversary decision.

## 5. MOVEit: the path through a useful, trusted data service

### 5.1 Established incident versus reconstructed mechanism

The joint advisory establishes the SQL-injection-driven MOVEit campaign, the C# web shell LEMURLOOT, database/file access capabilities, and the retained-account problem after web-host rebuilding [6]. Mandiant provides primary engagement and malware-analysis evidence [5]. Neither source proves that every victim experienced every described capability.

Horizon3's patch-difference research examines a query-construction change, removed session-state functionality, and an upload-state change. Its reconstructed route involves inconsistent request interpretation and state later consumed by a database operation. Crucially, the researchers state that their route may not be the attackers' exact path [19]. This supports a mechanism hypothesis and a negative lesson about assuming coverage, not a complete historical chain attributable to CL0P.

### 5.2 Architecture and stage-by-stage diagnosis

The relevant functional components are the externally reachable application, intermediary/request-handling logic, session and database state, file storage, and the identities permitted to access those stores. Some deployments also use external storage. Whether a component is present, how it is configured, and what actually happened must be established for the particular environment.

| Stage | Diagnostic issue | Observation that would discriminate | Unsupported shortcut to avoid |
|---|---|---|---|
| Vulnerable operation | Was a dangerous database operation merely reachable, or executed with attacker-influenced data? | Matched application and database evidence | Equating endpoint reachability with successful injection |
| Intermediary trust | Did each request-processing layer agree on operation and provenance? | Correlated representations at both boundaries | Treating localhost or an internal relay as proof of an authorized original caller |
| Durable identity | Was an unapproved account introduced or used? | Account creation/use history and ownership validation | Treating a service-like account name as sufficient attribution |
| File access | Which files were actually accessed or copied? | Storage access records and corroborating application evidence | Equating malware capability with every file being stolen |
| External authority | Was configuration authority exposed and still usable elsewhere? | Deployment-specific secret access and revocation/readback evidence | Assuming every MOVEit deployment used the same storage |
| Restoration | What state was retained when the web tier was rebuilt? | Database/account comparison and effective access checks | Inferring durable-state repair from a clean web filesystem |

The immediate engineering issue is the transfer of trust between layers. A useful internal relay legitimately performs work on behalf of an external request. The security boundary depends on preserving the meaning and provenance of that work. A later consumer cannot simply infer that state is safe because an earlier stage was expected to validate it.

This is my cross-case interpretation, not a claim to have discovered the historical flaw. In Equifax, the critical conversion included request processing into execution and execution into credential authority. In Exchange, it included request context into server-trusted operations. In MOVEit, the comparison asks how request/state interpretation can authorize later data operations. The labels differ, but every diagnosis must identify where data or context became authority.

### 5.3 What the patch history does and does not show

Progress's June 2023 updates describe further investigation, collaboration and additional security work after the initial disclosure [20,21]. The narrow inference is that a fix for a named weakness and a broader assurance about an application are different claims. The existence of subsequent fixes does not itself prove that a particular customer's earlier patch was ineffective against the original CVE, or that every later report belonged to the same exploited route.

Patch-difference evidence can reveal what changed. It cannot, without additional evidence, establish why every change was made, whether every change was necessary for the observed incident, or which version and configuration each victim ran. A diagnosis should connect the exact repaired behavior to the path being excluded, then examine the state already created by earlier access.

### 5.4 Alternatives and a smallest decisive test

A prepared database statement targets query interpretation. Validation of request provenance and operation agreement targets an intermediary boundary. Restricting identity creation targets a durable extension. Rebuilding a host targets host state. Invalidating external grants targets another authority plane. These are analytical intervention categories; the paper does not assert they are independently sufficient product fixes.

The smallest local test is to rebuild an inert application directory while preserving its account database, then query the account store and test the modeled permission separately. The executed S1 storage demonstration does exactly this at a synthetic state level. A stronger product-level study would require the actual application's authorization semantics, versions and replica behavior. That experiment was not performed.

The alternative path question should be precise. Could observed file access have occurred through a malicious web component, a durable application identity, or exposed external-storage authority? The public evidence supports investigating those possibilities where the environment permits them; it does not justify asserting that all were exercised. The decisive next record is the one that discriminates between those branches, not another repetition of the CVE description.

## 6. Cross-case diagnosis: routes, evidence, and intervention timing

### 6.1 A useful diagnosis has to distinguish explanations

The initial observation often underdetermines the mechanism. A public application can be vulnerable without having been exploited; a process can be compromised without gaining unrelated data; a mailbox can be read without leaving a durable implant; a clean host can coexist with a retained account. The task is to identify which additional observation changes the possible explanations.

| Starting observation | Competing explanations | Next discriminating evidence | Decision it can change |
|---|---|---|---|
| Vulnerable exposed component | No exploitation; failed exploitation; successful access | Correlated execution, identity or data-operation records | Prevention-only work versus incident scoping |
| No known malicious files | No compromise; direct data access; non-file authority | Data/identity-plane evidence with known coverage | Whether a clean filesystem supports the claimed scope |
| Abnormal database reads | Legitimate exceptional work; stolen identity; compromised application | Principal ownership, source process, timing and business purpose | Which boundary to contain and investigate |
| New privileged identity | Authorized maintenance; malicious creation; stale recovery artifact | Approved change record and effective use history | Removal, preservation, or further investigation |
| More incidents discovered after monitoring repair | Increased harm; unchanged harm newly visible | Independent event times and observation-coverage history | Whether a trend measures compromise or visibility |

Each proposed test has limits. A restored log source cannot recover events it never retained. A local status message can be wrong. Evidence can be stale or adversarially altered. Correlation can support a reconstruction without proving a unique cause. Where no retained observation can discriminate, the output should state the unresolved alternatives and select a containment action robust to them, with its business cost declared.

### 6.2 Compare controls by the paths they affect

Let P be the modeled routes to a protected objective. An intervention c has a declared affected set Cut(c,t), dependent on the incident state and time t. Complete modeled prevention requires every feasible route to be cut. A sensor instead changes what is observed about a route; it is not counted as a preventive cut unless an explicit, functioning response action closes that route.

An intervention can therefore improve observability while leaving access open, or remove a route while leaving historical disclosure unchanged. A data-minimization change can reduce potential consequence without fixing entry. These effects should be reported separately. This is established attack-graph and incident-response reasoning [8-10]; the contribution here is its evidence-linked application across the three cases and the tested temporal failure condition below.

The expensive mistake is to count controls that all depend on the same compromised component as independent barriers. If a trusted service can already perform a protected operation, denying unrelated network movement may not cut its direct path. If that service can issue replacement authority, revoking one descendant before restoring the issuer can be temporary. The corresponding tests are architectural, not an assumption that all defenses will fail.

### 6.3 Diagnose a transition, retained authority, and consequence separately

Three questions follow. What first admitted the unauthorized operation? What power or state remains available now? What outcome has already occurred? The answer can be immediate data access, a retained path, both, or neither. Neither the existence nor absence of a web shell settles all three questions.

This distinction informs the repair contract in the accompanying paper, but also governs pre-entry design review, live scoping, and selection of the next diagnostic test. An analyst can work backward from a protected operation through effective principals and state to the evidence supporting an entry mechanism. Unsupported links remain explicit instead of being filled with a plausible-sounding attack story.

