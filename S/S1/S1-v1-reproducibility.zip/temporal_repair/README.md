# Temporal Repair Dependencies — reproducibility artifact

Zawwar Sami | Version 1.0 | 16 October 2026

This package accompanies *When Revocation Does Not End Access: Temporal Repair Dependencies in Application Compromise*. It is a controlled synthetic service experiment, not an Exchange/MOVEit exploitation tool or a production recovery system.

## Run

Python 3.12 standard library; SQLite support and loopback sockets required. Run from the package root:

    python3 temporal_repair/check_graphs.py
    python3 temporal_repair/run_experiment.py

No third-party Python packages are needed for experiments. The PDF renderer additionally requires ReportLab and the DejaVu font family. The captured environment was Python3.12.14 / Linux6.18.44 / glibc2.39. Regeneration uses random ephemeral credentials, random canary digests and new process identities; compare verdict/count fields rather than expecting byte-identical JSON.

## Structure

- resource_service.py: loopback HTTP resource with principal/session SQLite tables, provisioning barrier and admission-authorized queue.
- issuer_service.py: separately running stipulated renewal source; restoration disables renewal.
- observer.py: separate process, HTTP-only readback; no service imports, state/database reads or repair helpers.
- run_experiment.py: schedule controller, assertions, artifact recording.
- check_graphs.py: independent bounded graph transition implementation.
- results/: exact executed JSON and CSV. Values are synthetic; credential secrets are excluded.
- Incident_Diagnostic_Notes.md: extended historical walkthroughs. Reference numbers match the paper.
- source_register.csv: reading scope and source locators.

R restores issuer; P clears resource principals; S clears sessions. Mask positions request renewal after the action in that position, not after a fixed action name. Three repeats of six orders times eight masks yield144 base trials (48 distinct schedules);18 barrier trials (six distinct);nine queue trials (three distinct). Two additional fault checks cover false acknowledgement and unavailable readback.

Expected summary:20/48 distinct base schedules open;60/144 repeated base trials open;18/18 synchronous barrier trials reject all issued credentials;late-drain queue reopens3/3;drain-before-revoke and cancellation reject in3/3 each;old handles reject in every base final state. All98,697 graph-order predictions match finite execution across4,165 graphs.

## Scope

Controllers are deliberately privileged over this synthetic fixture. Management endpoints are unauthenticated and bind only to127.0.0.1; do not deploy these educational services as production software. No real credential, exploit, malware, third-party target or victim telemetry is used. Same-host process separation is not independent administration or a tamper-resistant observer. Rejection proves only that the supplied credential inventory cannot perform the tested operation at that observation point.

The queue can commit accepted work after isolation because that is the deliberately declared admission-time authorization model. Other products may cancel jobs or reauthorize at commit. Do not infer their behavior from this fixture. Synchronous analytic prediction excludes the queue extension.

## Inspect a decisive trace

In results/http_results.json, choose repetition0, order disable-principals / restore-issuer / invalidate-sessions, mask100. Compare the initial credential rejections with the replacement principal's HTTP200. Then compare mask000. Inspect delayed_trials for late-drain versus drain-before-revoke and cancellation. All observers are separately launched process instances.

Counts are exhaustive constructed test coverage, not incident rates or human-performance estimates. No human study, vendor-product recovery benchmark or operational superiority claim is made.

Source-register identifiers L1–L27 map to references[1]–[27] in the paper. Case/evidence worksheets use those reference numbers. The graph proof excludes self-edges, which cannot reactivate an absent sole source in this model.

## Narrated HTTP walkthrough (version 1.1)

Run `python3 temporal_repair/walkthrough.py`. Three live local treatments compare admission-only containment, cancellation, and an issuance-epoch fence. A fourth positive control reopens provisioning and verifies new-epoch work succeeds. Output is saved in `results/walkthrough_transcript.txt` and `results/walkthrough_results.json`. These are additional demonstrations, not repetitions in the 171-trial matrix. The updated single-threaded resource records an epoch per queued job; `/fence` advances it, and `/drain` rejects stale jobs. `/isolate` preserves the original admission-only behavior. This is not a concurrent/distributed fencing implementation.
