"""Exhaustive bounded check of the renewal-edge scheduling condition.
All authority bits initially present; clearing a node does not permanently
prevent its recreation. Saturated renewal is an allowed worst-case schedule.
"""
import itertools, json
from pathlib import Path


def closure(state, edges):
    while True:
        nxt = state | sum(1 << v for v in set(v for u,v in edges if state & (1 << u)))
        if nxt == state: return state
        state = nxt


def execute(n, edges, order):
    state = (1 << n)-1
    for node in order:
        state &= ~(1 << node)
        state = closure(state, edges)
    return state


def main():
    counts=[]; example=None
    for n in range(1,5):
        candidates=[(u,v) for u in range(n) for v in range(n) if u != v]
        graphs=pairs=safe=mismatches=cyclic=0
        for mask in range(1 << len(candidates)):
            edges=[e for i,e in enumerate(candidates) if mask & (1 << i)]
            graphs += 1; valid_orders = 0
            for order in itertools.permutations(range(n)):
                pairs += 1; pos={v:i for i,v in enumerate(order)}
                predicted=all(pos[u]<pos[v] for u,v in edges)
                final=execute(n,edges,order); actual=(final == 0)
                mismatches += predicted != actual; safe += actual; valid_orders += predicted
                if predicted != actual:example={'n':n,'edges':edges,'order':order,'final':final}
            cyclic += valid_orders == 0
        counts.append(dict(n=n,graphs=graphs,graph_order_pairs=pairs,closed_pairs=safe,
                           cyclic_graphs=cyclic,prediction_mismatches=mismatches))
    assert not any(r['prediction_mismatches'] for r in counts), example
    result={'model':'All initially active; each node cleared once; all enabled edges may renew after every clear.',
            'counts':counts,'total_graphs':sum(r['graphs'] for r in counts),
            'total_graph_order_pairs':sum(r['graph_order_pairs'] for r in counts),
            'interpretation':'Bounded exhaustive check of a stated scheduling proposition; no service or incident prevalence.'}
    Path(__file__).with_name('results').joinpath('graph_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__ == '__main__': main()
