"""Synthetic renewal source. Compromise is stipulated, not exploited."""
import argparse, json, urllib.request, urllib.error
from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer


def serve(root, resource):
    root = Path(root); active = True
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args): pass
        def do_POST(self):
            nonlocal active
            if self.path == '/reset': active = True; code, body = 200, {'ack': True}
            elif self.path == '/restore': active = False; code, body = 200, {'ack': True}
            elif self.path in ('/renew', '/queue') and active:
                req = urllib.request.Request(resource + ('/queue' if self.path == '/queue' else '/provision'), data=b'', method='POST')
                try:
                    with urllib.request.urlopen(req, timeout=3) as r: code, body = r.status, json.load(r)
                except urllib.error.HTTPError as e: code, body = e.code, json.load(e)
            else: code, body = 403, {'error': 'renewal unavailable'}
            data = json.dumps(body).encode(); self.send_response(code)
            self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)
    http = HTTPServer(('127.0.0.1', 0), Handler)
    (root / 'issuer.port').write_text(str(http.server_port)); http.serve_forever()

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('root'); p.add_argument('resource')
    a = p.parse_args(); serve(a.root, a.resource)
