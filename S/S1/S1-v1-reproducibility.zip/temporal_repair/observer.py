"""Separate HTTP-only observer: no imports from services, no database/state reads."""
import hashlib, json, os, sys, urllib.request, urllib.error


def probe(base, credentials):
    rows = []
    for credential in credentials:
        for field, scheme in [('principal', 'Principal'), ('session', 'Bearer')]:
            secret = credential[field]
            req = urllib.request.Request(base + '/data', headers={'Authorization': scheme + ' ' + secret})
            try:
                with urllib.request.urlopen(req, timeout=3) as r:
                    body = json.load(r)
                    rows.append({'kind': field, 'fingerprint': hashlib.sha256(secret.encode()).hexdigest()[:12],
                                 'status': r.status, 'canary_digest': hashlib.sha256(body['canary'].encode()).hexdigest()})
            except urllib.error.HTTPError as e:
                rows.append({'kind': field, 'status': e.code})
            except (OSError, ValueError, KeyError):
                rows.append({'kind': field, 'status': 'unavailable'})
    if any(r['status'] == 200 for r in rows): verdict = 'open'
    elif not rows or any(r['status'] != 401 for r in rows): verdict = 'unresolved'
    else: verdict = 'closed-for-supplied-credentials'
    return {'observer_pid': os.getpid(), 'verdict': verdict, 'probes': rows}

if __name__ == '__main__':
    p = json.load(sys.stdin); print(json.dumps(probe(p['resource'], p['credentials'])))
