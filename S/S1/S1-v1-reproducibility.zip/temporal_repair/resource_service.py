"""Loopback-only synthetic protected resource; never target a production service."""
import argparse, hashlib, json, secrets, sqlite3
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path


def serve(root, port):
    root = Path(root); root.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(root / 'resource.sqlite')
    db.executescript('CREATE TABLE principal(secret TEXT PRIMARY KEY); CREATE TABLE session(secret TEXT PRIMARY KEY);')
    canary = secrets.token_hex(24)
    state = {'isolated': False, 'pending': [], 'epoch': 0}
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args): pass
        def reply(self, code, body):
            data = json.dumps(body).encode()
            self.send_response(code); self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)
        def do_GET(self):
            if self.path == '/health': return self.reply(200, {'pid': __import__('os').getpid()})
            if self.path != '/data': return self.reply(404, {})
            value = self.headers.get('Authorization', '').split(' ', 1)
            if len(value) != 2 or value[0] not in ('Principal', 'Bearer'):
                return self.reply(401, {'error': 'missing capability'})
            table = 'principal' if value[0] == 'Principal' else 'session'
            ok = db.execute(f'SELECT 1 FROM {table} WHERE secret=?', (value[1],)).fetchone()
            return self.reply(200 if ok else 401, {'canary': canary} if ok else {'error': 'revoked'})
        def do_POST(self):
            if self.path == '/reset':
                db.execute('DELETE FROM principal'); db.execute('DELETE FROM session'); db.commit()
                state['isolated'] = False; state['pending'] = []
                return self.reply(200, {'ack': True})
            if self.path == '/isolate':
                state['isolated'] = True
                return self.reply(200, {'ack': True})
            if self.path == '/fence':
                state['epoch'] += 1
                state['isolated'] = True
                return self.reply(200, {'ack': True, 'epoch': state['epoch']})
            if self.path == '/resume':
                state['isolated'] = False
                return self.reply(200, {'ack': True})
            if self.path == '/queue':
                if state['isolated']: return self.reply(403, {'error': 'provisioning blocked'})
                state['pending'].append(state['epoch'])
                return self.reply(202, {'accepted': True})
            if self.path == '/cancel-pending':
                state['pending'] = []
                return self.reply(200, {'ack': True})
            if self.path == '/drain':
                if not state['pending']: return self.reply(409, {'error': 'no pending work'})
                accepted_epoch = state['pending'].pop(0)
                if accepted_epoch != state['epoch']:
                    return self.reply(409, {'error': 'stale issuance epoch'})
                p, s = secrets.token_hex(24), secrets.token_hex(24)
                db.execute('INSERT INTO principal VALUES(?)', (p,))
                db.execute('INSERT INTO session VALUES(?)', (s,)); db.commit()
                return self.reply(201, {'principal': p, 'session': s})
            if self.path == '/provision':
                if state['isolated']: return self.reply(403, {'error': 'provisioning blocked'})
                p, s = secrets.token_hex(24), secrets.token_hex(24)
                db.execute('INSERT INTO principal VALUES(?)', (p,))
                db.execute('INSERT INTO session VALUES(?)', (s,)); db.commit()
                return self.reply(201, {'principal': p, 'session': s})
            if self.path in ('/disable-principals', '/invalidate-sessions', '/ack-only'):
                if self.path != '/ack-only':
                    table = 'principal' if self.path == '/disable-principals' else 'session'
                    db.execute(f'DELETE FROM {table}'); db.commit()
                return self.reply(200, {'ack': True})
            return self.reply(404, {})
    http = HTTPServer(('127.0.0.1', port), Handler)
    (root / 'resource.port').write_text(str(http.server_port)); http.serve_forever()

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('root'); p.add_argument('--port', type=int, default=0)
    a = p.parse_args(); serve(a.root, a.port)
