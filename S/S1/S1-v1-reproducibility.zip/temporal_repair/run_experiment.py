"""Exhaustive controlled repair schedules over loopback HTTP services."""
import csv, hashlib, itertools, json, os, platform, subprocess, sys, tempfile, time
from pathlib import Path
import urllib.request, urllib.error
ROOT = Path(__file__).resolve().parent
ACTIONS = ('restore-issuer', 'disable-principals', 'invalidate-sessions')


def post(base, path):
    request = urllib.request.Request(base + '/' + path, data=b'', method='POST')
    try:
        with urllib.request.urlopen(request, timeout=3) as r: return r.status, json.load(r)
    except urllib.error.HTTPError as e: return e.code, json.load(e)


def observe(resource, credentials):
    p = subprocess.run([sys.executable, str(ROOT / 'observer.py')],
                       input=json.dumps({'resource': resource, 'credentials': credentials}),
                       text=True, capture_output=True, check=True, timeout=10)
    return json.loads(p.stdout)


def launch(script, root, *args):
    p = subprocess.Popen([sys.executable, str(ROOT / script), str(root), *args], stdout=subprocess.DEVNULL)
    port_file = root / ('resource.port' if script.startswith('resource') else 'issuer.port')
    for _ in range(300):
        if port_file.exists(): return p, 'http://127.0.0.1:' + port_file.read_text()
        if p.poll() is not None: raise RuntimeError('service exited')
        time.sleep(.01)
    p.terminate(); raise TimeoutError('service startup')


def trial(resource, issuer, order, mask, isolated=False, fault=None):
    post(resource, 'reset'); post(issuer, 'reset')
    code, initial = post(issuer, 'renew'); assert code == 201
    credentials = [initial]; before = observe(resource, credentials)
    assert before['verdict'] == 'open'
    initial_digest = before['probes'][0]['canary_digest']
    if isolated: assert post(resource, 'isolate')[0] == 200
    trace = []
    for i, action in enumerate(order):
        endpoint = 'restore' if action == 'restore-issuer' else action
        if fault == 'ack-only' and action != 'restore-issuer': endpoint = 'ack-only'
        code, ack = post(issuer if action == 'restore-issuer' else resource, endpoint)
        assert code == 200 and ack['ack']
        renewal_status = None
        if mask[i]:
            renewal_status, cap = post(issuer, 'renew')
            if renewal_status == 201: credentials.append(cap)
        o = observe(resource, credentials)
        trace.append({'action': action, 'ack': True, 'renewal_attempt': bool(mask[i]),
                      'renewal_status': renewal_status, 'observation': o})
    final = trace[-1]['observation']
    # The last known old handles may fail while subsequently issued handles work.
    stale = observe(resource, [initial])
    last_creation = max([i for i,t in enumerate(trace) if t['renewal_status'] == 201], default=-1)
    predicted_open = False if isolated else any(order.index(a) <= last_creation for a in ACTIONS[1:])
    if fault is None:
        assert (final['verdict'] == 'open') == predicted_open, (order,mask,last_creation,final,trace)
    return {'order': order, 'mask': mask, 'isolated': isolated, 'fault': fault,
            'trace': trace, 'final': final['verdict'], 'old_handles': stale['verdict'],
            'credential_generations': len(credentials), 'historical_copy_digest': initial_digest,
            'prediction': 'open' if predicted_open else 'closed-for-supplied-credentials'}


def main():
    results = ROOT / 'results'; results.mkdir(exist_ok=True)
    rows = []; processes = []
    with tempfile.TemporaryDirectory(prefix='s1-http-') as td:
        root = Path(td)
        try:
            p, resource = launch('resource_service.py', root); processes.append(p)
            p, issuer = launch('issuer_service.py', root, resource); processes.append(p)
            for repetition in range(3):
                for order in itertools.permutations(ACTIONS):
                    for mask in itertools.product((0,1), repeat=3):
                        r = trial(resource, issuer, order, mask); r['repetition'] = repetition; rows.append(r)
                    r = trial(resource, issuer, order, (1,1,1), isolated=True)
                    r['repetition'] = repetition; rows.append(r)
            delayed = []
            for repetition in range(3):
                for mode in ('late-drain', 'drain-before-revoke', 'cancel-before-revoke'):
                    post(resource, 'reset'); post(issuer, 'reset')
                    code, initial = post(issuer, 'renew'); assert code == 201
                    assert post(issuer, 'queue')[0] == 202
                    post(resource, 'isolate'); post(issuer, 'restore')
                    assert post(issuer, 'renew')[0] == 403
                    creds = [initial]
                    if mode == 'drain-before-revoke':
                        status, cap = post(resource, 'drain'); assert status == 201; creds.append(cap)
                    if mode == 'cancel-before-revoke': post(resource, 'cancel-pending')
                    post(resource, 'disable-principals'); post(resource, 'invalidate-sessions')
                    old = observe(resource, creds)
                    status, cap = post(resource, 'drain')
                    if status == 201: creds.append(cap)
                    final = observe(resource, creds)
                    assert (final['verdict'] == 'open') == (mode == 'late-drain')
                    delayed.append({'repetition':repetition, 'mode':mode, 'before_drain':old,
                                    'drain_status':status, 'final':final})
            faults = [trial(resource, issuer, ACTIONS, (1,1,1), fault='ack-only')]
            unavailable = observe('http://127.0.0.1:1', [{'principal':'inert', 'session':'inert'}])
            assert unavailable['verdict'] == 'unresolved'
            assert faults[0]['final'] == 'open'
            service_pids = [p.pid for p in processes]
            assert all(t['observation']['observer_pid'] not in service_pids+[os.getpid()]
                       for r in rows for t in r['trace'])
        finally:
            for p in reversed(processes): p.terminate(); p.wait(timeout=5)
    base = [r for r in rows if not r['isolated']]
    summary = {'experiment':'temporal-repair-http-1.0', 'python':platform.python_version(),
        'platform': platform.platform(), 'controller_pid': os.getpid(), 'service_pids':service_pids,
        'delayed_trials':len(delayed), 'delayed_open':sum(r['final']['verdict']=='open' for r in delayed),
        'base_trials':len(base), 'isolated_trials':len(rows)-len(base),
        'base_open':sum(r['final']=='open' for r in base),
        'prediction_mismatches':sum(r['final']!=r['prediction'] for r in rows),
        'isolated_open':sum(r['isolated'] and r['final']=='open' for r in rows),
        'stale_handle_false_closures':sum(r['final']=='open' and r['old_handles']=='closed-for-supplied-credentials' for r in base),
        'ack_only_detected':faults[0]['final']=='open', 'unavailable_observer_verdict':unavailable['verdict'],
        'limits':['Synthetic stipulated issuer; no exploit or affected vendor product.',
                  'Separate processes, same OS user/host and author; not adversarially independent administration.',
                  'Three repeats verify execution consistency; not independent incident samples.',
                  'HTTP-only observer sees supplied issued credentials; completeness is a fixture assumption.']}
    (results/'http_results.json').write_text(json.dumps({'summary':summary,'trials':rows,'fault_trials':faults,'delayed_trials':delayed,'unavailable':unavailable},indent=2))
    with (results/'http_trials.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['repetition','order','renewal_mask','isolated','final','old_handles','generations'])
        for r in rows:w.writerow([r['repetition'],' > '.join(r['order']),''.join(map(str,r['mask'])),r['isolated'],r['final'],r['old_handles'],r['credential_generations']])
    (results/'http_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__ == '__main__': main()
