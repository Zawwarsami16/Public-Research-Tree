"""Run narrated HTTP recovery scenarios against disposable local services."""
import json, subprocess, tempfile
from pathlib import Path
from run_experiment import launch, post, observe

ROOT = Path(__file__).resolve().parent

def main():
    transcript = []
    def say(message):
        print(message, flush=True)
        transcript.append(message)
    rows = []
    processes = []
    with tempfile.TemporaryDirectory(prefix='s1-walkthrough-') as td:
        root = Path(td)
        try:
            p, resource = launch('resource_service.py', root); processes.append(p)
            p, issuer = launch('issuer_service.py', root, resource); processes.append(p)
            for treatment in ('admission-only', 'cancel-pending', 'epoch-fence'):
                say('\nSCENARIO ' + treatment)
                post(resource, 'reset'); post(issuer, 'reset')
                code, original = post(issuer, 'renew'); assert code == 201
                assert post(issuer, 'queue')[0] == 202
                say('Initial issuance: 201; queued issuance: 202 accepted')
                control = 'fence' if treatment == 'epoch-fence' else 'isolate'
                assert post(resource, control)[0] == 200
                post(issuer, 'restore')
                if treatment == 'cancel-pending': post(resource, 'cancel-pending')
                post(resource, 'disable-principals'); post(resource, 'invalidate-sessions')
                before = observe(resource, [original])
                assert before['verdict'] == 'closed-for-supplied-credentials'
                say('After repair: original principal=401; original session=401')
                status, created = post(resource, 'drain')
                creds = [original] + ([created] if status == 201 else [])
                final = observe(resource, creds)
                say('Drain accepted job: HTTP ' + str(status))
                say('Readback: ' + final['verdict'])
                assert (final['verdict'] == 'open') == (treatment == 'admission-only')
                rows.append({'treatment': treatment, 'before': before,
                             'drain_status': status, 'after': final})
            # Positive control: fencing must not permanently disable the service.
            post(resource, 'resume'); post(issuer, 'reset')
            assert post(issuer, 'queue')[0] == 202
            code, fresh = post(resource, 'drain'); assert code == 201
            fresh_observation = observe(resource, [fresh])
            assert fresh_observation['verdict'] == 'open'
            say('\nPOSITIVE CONTROL after reopening')
            say('New-epoch queue: 202; drain: 201; protected read: 200')
            rows.append({'treatment': 'new-epoch-positive-control', 'after': fresh_observation})
        finally:
            for p in reversed(processes):
                p.terminate(); p.wait(timeout=5)
    result = ROOT / 'results'
    (result / 'walkthrough_results.json').write_text(json.dumps(rows, indent=2))
    (result / 'walkthrough_transcript.txt').write_text('\n'.join(transcript) + '\n')

if __name__ == '__main__': main()
