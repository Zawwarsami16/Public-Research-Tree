# W2 v1.2 reproducible research materials

Zawwar Sami — 17 October 2026
What Development Evidence Can and Cannot Show: AAG, EMALS and model-dependent engineering tests.
Independent preprint; not peer reviewed. CC BY 4.0, excluding cited third-party material.

## Evidence classes

case_claims.csv contains four manual documentary transcriptions from three official NAVAIR accounts. Preserve their qualifiers and test boundaries. These are source-reported claims, not independent observations of carrier tests.

All other numerical example outputs are synthetic or exact model-conditional calculations. No field event logs, aircraft load traces, measured carrier improvement, reviewer study or financial saving are included. The 1.6 million Monte Carlo draws are synthetic total counts, drawn directly from the specified distributions, not physical trials.

## Run

Extract this archive retaining its directory tree. From the extracted root:

    python -m pip install -r output/w2_v1_2/requirements.txt
    python output/w2_v1_2/w2_experiments.py
    python output/w2_v1_2/verify_core.py

The full script writes exact calculations, seeded simulated frequencies, observed histogram counts, planning grids, normalized work sensitivity, renewal sensitivity and two numerical figures. The root seed is 20261016 with eight independently spawned streams, one per model/truth combination. NumPy 2.3.5 and SciPy 1.17.0 were used in the retained execution. Re-running changes the timestamp in execution_log.txt; the numerical outputs use fixed inputs and seed. Small platform-dependent floating-point differences are possible. The unabridged execution log records the retained run; Appendix D prints the compact verifier and selected Monte Carlo outputs.

The Wilson intervals quantify Monte Carlo sampling uncertainty, not uncertainty in actual equipment reliability. The exact alternatives and dispersion are assumed known. Common block effects, different costs or unknown parameters require a different calculation.

## Optional PDF rebuild

    mkdir -p output/pdf
    python output/w2_v1_2/render_w2.py

The renderer uses DejaVu fonts at /usr/share/fonts/truetype/dejavu and the retained figure files. Its Markdown markers are expanded into captions, tables, equations, references, figures and the Appendix D code listing. To attach this archive after rendering:

    python output/w2_v1_2/embed_bundle.py path/to/paper.pdf path/to/W2-v1.2-reproducibility.zip

The distributed PDF already contains the byte-verified attachment. A PDF viewer's Attachments panel can extract it. In Python, `fitz.open(pdf).embfile_get('W2-v1.2-reproducibility.zip')` returns the ZIP bytes. Appendix D prints an executable compact verification script for viewers that do not expose embedded files. The separate ZIP may be deposited alongside the manuscript; paper DOI and deposit identifier: https://doi.org/10.5281/zenodo.23435836. The archive is also supplied separately and embedded in the PDF.

## Integrity

MANIFEST.sha256 records every included file except itself. Verify those hashes before modifying or rerunning the files; rerunning intentionally rewrites generated outputs. source_ledger.json records URLs and access quality. All figures are original drawings or numerical plots; execution_record.png is a faithful text rendering of selected captured stdout, not a simulated hardware-test screenshot.
