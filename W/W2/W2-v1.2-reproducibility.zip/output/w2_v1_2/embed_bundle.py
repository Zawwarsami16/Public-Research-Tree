"""Attach a reproducibility ZIP to an already rendered PDF. Requires PyMuPDF.
Usage: python embed_bundle.py path/to/paper.pdf path/to/bundle.zip
"""
from pathlib import Path
import sys,hashlib
import fitz
pdf,bundle=map(Path,sys.argv[1:3]);raw=bundle.read_bytes();name=bundle.name
with fitz.open(pdf) as d:
    if name in d.embfile_names():d.embfile_del(name)
    d.embfile_add(name,raw,filename=name,ufilename=name,
                  desc='W2 v1.2 executable research materials and source ledger')
    d.saveIncr()
with fitz.open(pdf) as d:
    assert d.embfile_get(name)==raw
print('Embedded attachment verified:',name,hashlib.sha256(raw).hexdigest())
