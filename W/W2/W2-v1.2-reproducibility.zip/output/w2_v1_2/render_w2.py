from pathlib import Path
import json,re,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,KeepTogether,PageBreak,Preformatted
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import Drawing,Rect,String,Line,Polygon
from PIL import Image as PILImage

ROOT=Path(__file__).resolve().parents[2]
SUP=ROOT/'output/w2_v1_2';OUT=ROOT/'output/pdf'
FONTS=Path('/usr/share/fonts/truetype/dejavu')
for name,file in [('Body','DejaVuSerif.ttf'),('BodyBold','DejaVuSerif-Bold.ttf'),('Sans','DejaVuSans.ttf'),('SansBold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(FONTS/file)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='BodyBold',italic='Body',boldItalic='BodyBold')
pdfmetrics.registerFontFamily('Sans',normal='Sans',bold='SansBold',italic='Sans',boldItalic='SansBold')
RED=colors.HexColor('#831b32'); INK=colors.HexColor('#202631');GRAY=colors.HexColor('#555e69')
W,H=A4; CW=W-108
styles={
 'title':ParagraphStyle('title',fontName='SansBold',fontSize=23,leading=28,textColor=INK,spaceAfter=10),
 'subtitle':ParagraphStyle('subtitle',fontName='Sans',fontSize=13,leading=18,textColor=RED,spaceAfter=12),
 'h':ParagraphStyle('h',fontName='SansBold',fontSize=12,leading=16,textColor=RED,spaceBefore=14,spaceAfter=7,keepWithNext=True),
 'body':ParagraphStyle('body',fontName='Body',fontSize=10.1,leading=14.9,textColor=INK,spaceAfter=8,allowWidows=0,allowOrphans=0),
 'caption':ParagraphStyle('caption',fontName='Sans',fontSize=8.5,leading=12,textColor=GRAY,spaceBefore=4,spaceAfter=11),
 'cell':ParagraphStyle('cell',fontName='Sans',fontSize=8.0,leading=11,textColor=INK),
 'th':ParagraphStyle('th',fontName='SansBold',fontSize=8.0,leading=11,textColor=colors.white),
 'eq':ParagraphStyle('eq',fontName='Body',fontSize=10,leading=15,textColor=INK,leftIndent=8,spaceBefore=6,spaceAfter=12),
 'ref':ParagraphStyle('ref',fontName='Sans',fontSize=8.3,leading=12,textColor=INK,spaceAfter=8),
}

SOURCES=[('Sami, Z. (2026). Weapons as Systems: Components, Infrastructure and Human Organisation. W1, v1.0, 14 October. Independent preprint.', 'https://zenodo.org/records/23359788', 'Author PDF and repository read'), ('U.S. Department of Defense Inspector General. (2016, July 5). Advanced Arresting Gear Program Exceeded Cost and Schedule Baselines (Redacted). DODIG-2016-107. Printed pp. 4-5, 8-10.', 'https://www.dodig.mil/Reports/Audits-and-Evaluations/Article/1119295/advanced-arresting-gear-program-exceeded-cost-and-schedule-baselines-redacted/', 'Released original report read on mirror; original listing checked'), ('NAVAIR. (n.d.). Advanced Arresting Gear (AAG). Product description. Accessed 16 October 2026.', 'https://www.navair.navy.mil/product/advanced-arresting-gear-aag', 'Original page'), ('NAVAIR. (2017, January 23). AAG remains Navy’s choice for next-gen recovery system.', 'https://www.navair.navy.mil/node/24591', 'Original dated account'), ('NAVAIR. (2008, September 23). Carrier-based launch system reaches milestone.', 'https://www.navair.navy.mil/node/10976', 'Original dated account'), ('NAVAIR. (2022, July 5). EMALS and AAG reach 10,000 aircraft launches and recoveries.', 'https://www.navair.navy.mil/news/EMALS-and-AAG-reach-10000-aircraft-launches-and-recoveries/Tue-07052022-1019', 'Original dated account'), ('NAVAIR. (n.d.). Electromagnetic Aircraft Launch System (EMALS). Product description. Accessed 16 October 2026.', 'https://www.navair.navy.mil/product/Electromagnetic-Aircraft-Launch-System-EMALS', 'Original page'), ('U.S. Government Accountability Office. (2013, September 5). Ford-Class Carriers: Lead Ship Testing and Reliability Shortfalls Will Limit Initial Fleet Capabilities. GAO-13-396.', 'https://www.gao.gov/products/gao-13-396', 'Original findings and recommendations page'), ('NASA Kennedy Space Center. (n.d.). Availability. Three-page technical note, revision identifier 240607. Accessed 16 October 2026.', 'https://extapps.ksc.nasa.gov/Reliability/Documents/Availability_What_is_it.pdf', 'Original PDF, all three pages'), ('NIST/SEMATECH. (n.d.). e-Handbook of Statistical Methods, 8.4.5.1: Constant repair rate (HPP/exponential) model. Accessed 16 October 2026.', 'https://itl.nist.gov/div898/handbook/apr/section4/apr451.htm', 'Original section'), ('National Research Council. (2015). Reliability Growth: Enhancing Defense System Reliability. Chapter 7, Developmental Test and Evaluation. National Academies Press. doi:10.17226/18987.', 'https://www.nationalacademies.org/read/18987/chapter/9', 'Original chapter; selected technical sections'), ('Burclová, K., and Pázman, A. (2015). Optimum design via I-divergence for stable estimation in generalized regression models. arXiv:1507.07443v1. doi:10.48550/arXiv.1507.07443.', 'https://arxiv.org/abs/1507.07443', 'Original author manuscript, HTML: introduction and sections 2-4'), ("Burns, D. E., Vlajic, N., Chijioke, A., and Parker, P. A. (2022). Aerodynamic Metrologists Guide to Dynamic Force Measurement. Journal of Aircraft. doi:10.2514/1.C036676.", 'https://doi.org/10.2514/1.C036676', 'Original author PDF, abstract and selected dynamic-response/metrology sections; NIST listing checked'), ('NIST/SEMATECH. (n.d.). e-Handbook of Statistical Methods, 5.3.3.3.1: Two-level full factorial designs. Accessed 16 October 2026.', 'https://www.itl.nist.gov/div898/handbook/pri/section3/pri3331.htm', 'Original section'), ('SciPy community. (2026). scipy.stats.nbinom. SciPy v1.27.0 reference manual.', 'https://docs.scipy.org/doc/scipy-1.17.0/reference/generated/scipy.stats.nbinom.html', 'Version-matched original documentation'), ('Schmidt, M., and Schwabe, R. (2018). Optimal Designs for Poisson Count Data with Gamma Block Effects. arXiv:1808.05412v1.', 'https://arxiv.org/abs/1808.05412', 'Original author manuscript HTML; sections 1-3')]
MIRROR='https://www.defensedaily.com/wp-content/uploads/post_attachment/136651.pdf'

def esc(t):
    t=html.escape(t)
    t=t.replace('https://doi.org/10.5281/zenodo.23435836','<link href="https://doi.org/10.5281/zenodo.23435836" color="#831b32">https://doi.org/10.5281/zenodo.23435836</link>')
    for raw,formatted in [('n_j^2','n<sub>j</sub><super>2</super>'),('t_j^2','t<sub>j</sub><super>2</super>'),('mu_j','μ<sub>j</sub>'),('n_j','n<sub>j</sub>'),('t_j','t<sub>j</sub>'),('I_aa','I<sub>aa</sub>'),('I_bb','I<sub>bb</sub>'),('I_ab^2','I<sub>ab</sub><super>2</super>'),('I_ab','I<sub>ab</sub>'),('p_A','p<sub>A</sub>'),('p_B','p<sub>B</sub>'),('P_A','P<sub>A</sub>'),('P_B','P<sub>B</sub>'),('g_delta','g<sub>δ</sub>'),('f_delta','f<sub>δ</sub>')]:
        t=t.replace(raw,formatted)
    for raw,formatted in [('theta_L','θ<sub>L</sub>'),('theta_0','θ<sub>0</sub>'),('theta','θ'),('delta','δ'),('kappa','κ'),('mu','μ'),('nu','ν')]:
        t=re.sub(r'\b'+raw+r'\b',lambda m:formatted,t)
    for raw,formatted in [('alpha x','α x'),('beta z','β z'),('gamma xz','γ xz'),('gamma=0','γ=0'),('alpha,beta,gamma','α,β,γ')]:t=t.replace(raw,formatted)
    t=t.replace('μ^2','μ<super>2</super>').replace('2^S','2<super>S</super>')
    t=t.replace('δ','<font name="Sans">δ</font>')
    return re.sub(r'\*\*(.*?)\*\*',r'<b>\1</b>',t)

def architecture():
    d=Drawing(CW,185)
    xs=[4,170,336]; bw=147;bh=37
    def box(x,y,label,fill='#f4f5f7'):
        d.add(Rect(x,y,bw,bh,rx=4,fillColor=colors.HexColor(fill),strokeColor=colors.HexColor('#aeb5bf'),strokeWidth=.7))
        for i,l in enumerate(label.split('|')):d.add(String(x+bw/2,y+bh/2+5-11*i,l,fontName='Sans',fontSize=8.4,textAnchor='middle',fillColor=INK))
    def arrow(x1,y1,x2,y2):
        d.add(Line(x1,y1,x2,y2,strokeColor=RED,strokeWidth=1))
        if y1==y2:d.add(Polygon([x2,y2,x2-5,y2+3,x2-5,y2-3],fillColor=RED,strokeColor=RED))
        else:d.add(Polygon([x2,y2,x2-3,y2-5,x2+3,y2-5],fillColor=RED,strokeColor=RED))
    for x,l in zip(xs,['Aircraft motion','Arresting interface','Shock absorption /|water twister']):box(x,135,l)
    arrow(151,153,169,153);arrow(317,153,335,153)
    for x,l in zip(xs,['Power support','Digital control','Measurements']):box(x,68,l)
    arrow(151,86,169,86)
    d.add(Line(336,86,318,86,strokeColor=RED,strokeWidth=1))
    d.add(Polygon([318,86,323,89,323,83],fillColor=RED,strokeColor=RED))
    d.add(Line(243,105,243,119,strokeColor=RED,strokeWidth=1))
    d.add(Line(243,119,409,119,strokeColor=RED,strokeWidth=1))
    arrow(409,119,409,134)
    d.add(Rect(4,8,479,35,rx=4,fillColor=colors.HexColor('#f9eef1'),strokeColor=RED,strokeWidth=.6))
    d.add(String(CW/2,28,'Operators, maintainers, configuration and observation records',fontName='Sans',fontSize=8.5,textAnchor='middle',fillColor=INK))
    d.add(String(CW/2,16,'Support and evidential relationships across the arrangement',fontName='Sans',fontSize=7.5,textAnchor='middle',fillColor=GRAY))
    return d

def decision_tree():
    d=Drawing(CW,257)
    def box(x,y,w,h,label,fill='#f4f5f7'):
        d.add(Rect(x,y,w,h,rx=3,fillColor=colors.HexColor(fill),strokeColor=colors.HexColor('#aeb5bf'),strokeWidth=.6))
        for j,t in enumerate(label.split('|')):d.add(String(x+w/2,y+h/2+3-10*j,t,fontName='Sans',fontSize=7.7,textAnchor='middle',fillColor=INK))
    def arr(x,y,xx,yy,label=None):
        d.add(Line(x,y,xx,yy,strokeColor=RED,strokeWidth=.8))
        if x==xx:d.add(Polygon([xx,yy,xx-3,yy+5,xx+3,yy+5],fillColor=RED,strokeColor=RED))
        else:d.add(Polygon([xx,yy,xx-5,yy+3,xx-5,yy-3],fillColor=RED,strokeColor=RED))
        if label:d.add(String((x+xx)/2+(14 if x==xx else 0),(y+yy)/2+3,label,fontName='Sans',fontSize=7,textAnchor='middle',fillColor=GRAY))
    box(20,224,207,27,'Claim and tested boundary', '#f9eef1')
    arr(123,224,123,208)
    steps=[(178,'Records and definitions match?','Recover matched records'),(126,'Alternatives structurally separate?','Add a discriminating contrast'),(74,'Sampling precision adequate?','Replicate under justified model'),(22,'Configuration transfer justified?','Stratify and test transfer')]
    for j,(y,lab,action) in enumerate(steps):
        box(20,y,207,30,lab);box(280,y,187,30,action)
        arr(227,y+15,280,y+15,'No')
        if j<3:arr(123,y,123,y-22,'Yes')
    d.add(String(123,7,'Yes: retain the bounded conclusion',fontName='SansBold',fontSize=7.8,textAnchor='middle',fillColor=RED))
    return d

def header(c,doc):
    c.saveState();c.setStrokeColor(RED);c.setLineWidth(.7);c.line(54,H-37,W-54,H-37)
    c.setFont('Sans',7);c.setFillColor(GRAY)
    c.drawString(54,H-29,'ZAWWAR SAMI / W2')
    c.drawRightString(W-54,H-29,doc.packet_label)
    c.line(54,38,W-54,38);c.drawString(54,25,'17 OCTOBER 2026  /  W2  /  VERSION 1.2')
    c.drawRightString(W-54,25,str(doc.page));c.restoreState()

def render(src,dest,label):
    lines=src.read_text().splitlines();story=[];i=0;tablecaption=None
    while i<len(lines):
        l=lines[i].strip()
        if not l:i+=1;continue
        if l=='PAGEBREAK':story.append(PageBreak());i+=1;continue
        if l.startswith('TABLECAP:'):
            tablecaption=l.split(':',1)[1].strip();i+=1;continue
        if l.startswith('BOX:'):
            title=l.split(':',1)[1].strip();parts=[Paragraph(esc(title),styles['h'])];i+=1
            while i<len(lines) and lines[i].strip()!='ENDBOX':
                row=lines[i].strip()
                if row:parts.append(Paragraph('• '+esc(row.lstrip('- ')),styles['caption']))
                i+=1
            t=Table([[parts]],colWidths=[CW]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#f9eef1')),('BOX',(0,0),(-1,-1),.7,RED),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),8)]))
            story.extend([t,Spacer(1,8)]);i+=1;continue
        if l.startswith('CHECK:'):
            story.append(Paragraph('□ '+esc(l.split(':',1)[1].strip()),ParagraphStyle('check',parent=styles['caption'],fontSize=8.6,leading=12,spaceAfter=7)));i+=1;continue
        if l.startswith('CODEFILE:'):
            code=(SUP/l.split(':',1)[1].strip()).read_text()
            story.append(Preformatted(code,ParagraphStyle('code',fontName='Mono',fontSize=8,leading=10,textColor=INK,spaceBefore=8,spaceAfter=8)));i+=1;continue
        if l.startswith('DOI:'):
            story.append(Paragraph('<link href="https://doi.org/10.5281/zenodo.23435836" color="#831b32">DOI: 10.5281/zenodo.23435836</link>',styles['caption']));i+=1;continue
        if l=='REFERENCES':
            for n,(t,u,s) in enumerate(SOURCES,1):
                extra=f'<br/>Released-report mirror: <link href="{MIRROR}" color="#831b32">{MIRROR}</link>' if n==2 else ''
                story.append(Paragraph(f'[{n}] {esc(t)}<br/><link href="{html.escape(u,quote=True)}" color="#831b32">{html.escape(u)}</link>'+extra,styles['ref']))
            i+=1;continue
        if l.startswith('FIGURE:'):
            name=l.split(':',1)[1].strip();cap=''
            j=i+1
            while j<len(lines) and not lines[j].strip():j+=1
            if j<len(lines) and lines[j].startswith('CAPTION:'):
                cap=lines[j].split(':',1)[1].strip();j+=1
            if name=='architecture':fig=architecture()
            elif name=='decision_tree':fig=decision_tree()
            else:
                with PILImage.open(SUP/name) as im:iw,ih=im.size
                fig=Image(str(SUP/name),width=CW,height=CW*ih/iw)
            story.append(KeepTogether([Spacer(1,6),fig,Paragraph(esc(cap),styles['caption'])]));i=j;continue
        if l.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                row=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.match(r'^[-: ]+$',x) for x in row):rows.append(row)
                i+=1
            nc=len(rows[0]);widths=[CW/nc]*nc
            if nc==4:widths=[CW*.23,CW*.25,CW*.25,CW*.27]
            if nc==5:widths=[CW*.26]+[CW*.185]*4
            if nc==3:widths=[CW*.24,CW*.36,CW*.40]
            data=[[Paragraph(esc(x),styles['th' if r==0 else 'cell']) for x in row] for r,row in enumerate(rows)]
            t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),RED),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f3f4f6'),colors.white]),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#b8bec5'))]))
            tableheight=t.wrap(CW,10000)[1]
            cap=Paragraph(esc(tablecaption),styles['caption']) if tablecaption else Spacer(1,1)
            group=[cap,t]
            story.extend([Spacer(1,4),KeepTogether(group) if tableheight<350 else cap])
            if tableheight>=350:story.append(t)
            story.append(Spacer(1,12));tablecaption=None;continue
        if l.startswith('### '):story.append(Paragraph(esc(l[4:]),styles['h']));i+=1;continue
        if l.startswith('## '):story.append(Paragraph(esc(l[3:]),styles['subtitle']));i+=1;continue
        if l.startswith('# '):story.append(Paragraph(esc(l[2:]),styles['title']));i+=1;continue
        if l.startswith('EQUATION:'):
            eq=l.split(':',1)[1].strip()
            if eq.startswith('det I'):
                with PILImage.open(SUP/'equation_4.png') as im: ew,eh=im.size
                story.extend([Spacer(1,5),Image(str(SUP/'equation_4.png'),width=345,height=345*eh/ew,hAlign='LEFT'),Spacer(1,12)])
                i+=1;continue
            eqs={
             'renewal_bound': 'θ<sub>L</sub> = νN / G<sub>ν</sub><super>-1</super>(0.95).',
             'information_entries': 'I<sub>aa</sub> = Σ<sub>j</sub> n<sub>j</sub><super>2</super>/μ<sub>j</sub>; I<sub>bb</sub> = Σ<sub>j</sub> t<sub>j</sub><super>2</super>/μ<sub>j</sub>; I<sub>ab</sub> = Σ<sub>j</sub> n<sub>j</sub>t<sub>j</sub>/μ<sub>j</sub>.',
             'nb_log_ratio': 'log LR = rκ ln(p<sub>A</sub>/p<sub>B</sub>) + S ln[(1-p<sub>A</sub>)/(1-p<sub>B</sub>)].',
             'integral_0': '∫<sub>0</sub><super>1</super> f(u) du = 1; F<sub>peak</sub> = (W/L) max f(u).  (1)',
             'theta_lower': 'θ<sub>L,0.95</sub> = N / [-ln(0.05)].  (2)',
             'Y_j': 'Y<sub>j</sub> ~ Poisson(μ<sub>j</sub>), μ<sub>j</sub> = a n<sub>j</sub> + b t<sub>j</sub>, a,b ≥ 0.  (3)',
             'det I': 'det I = Σ<sub>i&lt;j</sub> (n<sub>i</sub>t<sub>j</sub> - n<sub>j</sub>t<sub>i</sub>)<super>2</super> / (μ<sub>i</sub>μ<sub>j</sub>).  (4)'
            }
            eq=next((v for k,v in eqs.items() if eq.startswith(k)),esc(eq))
            story.append(Paragraph(eq,styles['eq']));i+=1;continue
        para=[l];i+=1
        while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','FIGURE:','CAPTION:','EQUATION:','TABLECAP:','BOX:','ENDBOX','PAGEBREAK','CODEFILE:','CHECK:')):
            para.append(lines[i].strip());i+=1
        story.append(Paragraph(esc(' '.join(para)),styles['body']))
    doc=SimpleDocTemplate(str(dest),pagesize=A4,leftMargin=54,rightMargin=54,topMargin=51,bottomMargin=53,title='W2 - '+label,author='Zawwar Sami')
    doc.packet_label=label.upper();doc.build(story,onFirstPage=header,onLaterPages=header)

if __name__=='__main__':
    render(SUP/'W2_Manuscript_v1.2.md',OUT/'Zawwar-Sami-W2-What-Development-Evidence-Can-and-Cannot-Show-v1.2.pdf','Development evidence and engineering tests')
