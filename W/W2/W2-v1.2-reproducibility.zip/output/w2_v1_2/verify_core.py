# W2 v1.2: synthetic numerical verification. Python, NumPy, SciPy.
import math
import numpy as np
from scipy.stats import poisson, nbinom, gamma
from scipy.integrate import quad

def errors(r, k=None):
    if k is None:
        h = math.floor(2*r/math.log(2)) + 1
        A, B = poisson(4*r), poisson(2*r)
    else:
        pA, pB = k/(k+4), k/(k+2)
        h = math.floor(-r*k*math.log(pA/pB) /
                       math.log((1-pA)/(1-pB))) + 1
        A, B = nbinom(r*k, pA), nbinom(r*k, pB)
    return float(B.sf(h-1)), float(A.cdf(h-1))

first = []
for k in [None, 5, 2, 1]:
    r0 = next(r for r in range(1,501) if max(errors(r,k)) <= .05)
    first.append(r0)
    print(k, errors(10,k), r0)
assert first == [9, 13, 22, 34]

def features(X):
    return np.column_stack((X, X[:,0]*X[:,1]))
fixed = np.array([[1,1],[1,3],[1,5]], float)
factor = np.array([[1,1],[1,3],[2,1],[2,3]], float)
C, D = np.array([1,1,0]), np.array([1,0,1])
assert np.allclose(features(fixed)@C, features(fixed)@D)
assert np.linalg.matrix_rank(features(fixed)) == 2
assert np.linalg.matrix_rank(features(factor)) == 3
for v in [0.5, 1, 2, 5]:
    lo = 10000*v/gamma.ppf(.95,v)
    assert abs(gamma.sf(10000,v,scale=lo/v)-.05) < 1e-12
assert math.ceil(-5000*math.log(.05)) == 14979
for d in [1, 0.5, 0.25, 0.1]:
    def f(u):
        return .5+(1/d)*(1-abs(2*u/d-1)) if 0<=u<=d else .5
    assert abs(quad(f,0,1,points=[d/2,d])[0]-1) < 1e-12
    assert abs(f(d/2)-(.5+1/d)) < 1e-12
print('All compact checks passed.')
