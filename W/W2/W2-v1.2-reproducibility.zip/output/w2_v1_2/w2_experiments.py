"""W2 v1.2: executed synthetic robustness experiments; no field observations.
Run: python w2_experiments.py
Outputs deterministic exact calculations, seeded Monte Carlo counts/histograms,
interaction-design checks, sensitivity CSVs, plots and an execution log.
"""
from pathlib import Path
import csv,json,math,platform,hashlib,sys
from datetime import datetime,timezone
import numpy as np
import scipy
from scipy.stats import poisson,nbinom,gamma,norm
from scipy.integrate import quad
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
log=[]
def emit(s):log.append(s);print(s)
def csvsave(name,rows):
 with (R/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def rule(r,k):
 if k is None:return math.floor(2*r/math.log(2))+1
 return math.floor(-r*k*math.log((k+2)/(k+4))/math.log(2*(k+2)/(k+4)))+1
def dist(r,mu,k):return poisson(r*mu) if k is None else nbinom(r*k,k/(k+mu))
def errors(r,k,cutoff=None):
 h=rule(r,k) if cutoff is None else cutoff
 return h,float(dist(r,2,k).sf(h-1)),float(dist(r,4,k).cdf(h-1))
def directcdf(h,r,mu,k):
 if k is None:
  p=math.exp(-r*mu);s=p
  for j in range(1,h):p*=r*mu/j;s+=p
 else:
  shape=r*k;prob=k/(k+mu);p=prob**shape;s=p
  for j in range(1,h):p*=((j-1+shape)/j)*(1-prob);s+=p
 return s
def wilson(count,n,z=1.959963984540054):
 p=count/n;den=1+z*z/n;mid=(p+z*z/(2*n))/den
 half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
 return mid-half,mid+half
emit('W2 v1.2 | synthetic computation, not equipment data')
emit('UTC execution: '+datetime.now(timezone.utc).isoformat())
emit(f'Python {platform.python_version()} | NumPy {np.__version__} | SciPy {scipy.__version__}')
SEED=20261016;M=200000;seedseq=np.random.SeedSequence(SEED).spawn(8)
emit(f'Root seed {SEED}; 8 independent batches x {M:,} total-count draws = {8*M:,}')
robust=[];hist=[];idx=0;grids=[]
for k,label in [(None,'Poisson'),(5,'NB kappa=5'),(2,'NB kappa=2'),(1,'NB kappa=1')]:
 h,eB,eA=errors(10,k);hp=rule(10,None)
 # Independent probability recurrence validates exact CDF/SF calculations.
 assert abs(eB-(1-directcdf(h,10,2,k)))<1e-12
 assert abs(eA-directcdf(h,10,4,k))<1e-12
 minr=next(r for r in range(1,501) if max(errors(r,k)[1:])<=.05)
 min_fixed=next(r for r in range(1,501) if max(errors(r,k,rule(r,None))[1:])<=.05)
 row={'model':label,'kappa':'infinity' if k is None else k,'r':10,'matched_cutoff':h,'exact_false_A':eB,'exact_false_B':eA,'poisson_rule_false_A':errors(10,k,hp)[1],'poisson_rule_false_B':errors(10,k,hp)[2],'min_r_both_errors_le_05_matched':minr,'min_r_both_errors_le_05_poisson_rule':min_fixed}
 for mu,truth,errkey in [(2,'B','false_A'),(4,'A','false_B')]:
  rng=np.random.default_rng(seedseq[idx]);idx+=1
  s=rng.poisson(10*mu,size=M) if k is None else rng.negative_binomial(10*k,k/(k+mu),size=M)
  errs=int(np.sum(s>=h) if truth=='B' else np.sum(s<h));lo,hi=wilson(errs,M)
  row['mc_'+errkey+'_count']=errs;row['mc_'+errkey]=errs/M;row['mc_'+errkey+'_wilson_lo']=lo;row['mc_'+errkey+'_wilson_hi']=hi
  counts=np.bincount(s)
  hist.extend({'model':label,'truth':truth,'S':j,'frequency':int(c)} for j,c in enumerate(counts) if c)
  exact=eB if truth=='B' else eA
  row['mc_'+errkey+'_standardized_deviation']=(errs/M-exact)/math.sqrt(exact*(1-exact)/M)
 for r in range(1,101):
  hr,eb,ea=errors(r,k);grids.append({'model':label,'r':r,'cutoff':hr,'false_A':eb,'false_B':ea})
 robust.append(row)
 emit(f'{label:11s} r=10 h={h}: exact errors {eB:.6f}/{eA:.6f}; MC {row["mc_false_A"]:.6f}/{row["mc_false_B"]:.6f}; min r={minr}')
csvsave('robustness.csv',robust);csvsave('monte_carlo_histograms.csv',hist);csvsave('power_grid.csv',grids)
# Linear predictor families in normalized exposures x=n/1000,z=t/100.
same=np.array([[1,1],[2,2],[3,3]],float)
fixed=np.array([[1,1],[1,3],[1,5]],float)
factor=np.array([[1,1],[1,3],[2,1],[2,3]],float)
feat=lambda x:np.column_stack((x,x[:,0]*x[:,1]))
C=np.array([1,1,0.]);D=np.array([1,0,1.])
assert np.linalg.matrix_rank(feat(same))==2
assert np.linalg.matrix_rank(fixed)==2 and np.linalg.matrix_rank(feat(fixed))==2
assert np.linalg.matrix_rank(feat(factor))==3
assert np.allclose(feat(fixed)@C,feat(fixed)@D)
assert np.allclose(feat(factor)@C,[2,4,3,5]) and np.allclose(feat(factor)@D,[2,4,4,8])
interactions=[{'x':float(x),'z':float(z),'mu_C':float(c),'mu_D':float(d)} for (x,z),c,d in zip(factor,feat(factor)@C,feat(factor)@D)]
csvsave('interaction_design.csv',interactions)
emit('Interaction audit: same-ratio rank=2/3; fixed-cycle dwell rank=2/3; factorial rank=3/3')
# Fisher determinant identity in original cycle/hour units.
X=np.array([[1000.,100.],[1000.,300.],[2000.,100.]])
mu=X@np.array([.001,.01]);I=X.T@np.diag(1/mu)@X
rhs=sum((X[i,0]*X[j,1]-X[j,0]*X[i,1])**2/(mu[i]*mu[j]) for i in range(len(X)) for j in range(i+1,len(X)))
assert np.isclose(np.linalg.det(I),rhs,rtol=1e-12)
# Zero-event sensitivity: ordinary gamma renewal, known shape, fresh start.
renew=[]
for nu in [.5,1,2,5]:
 thetaL=10000*nu/gamma.ppf(.95,nu)
 assert abs(gamma.sf(10000,nu,scale=thetaL/nu)-.05)<1e-12
 renew.append({'known_shape_nu':nu,'exposure_N':10000,'lower95_mean_interval':float(thetaL)})
csvsave('renewal_sensitivity.csv',renew)
thresholds=[]
for th in [1000,5000,10000]:thresholds.append({'hypothetical_theta_target':th,'alpha':.05,'minimum_zero_event_exposure_hpp':math.ceil(-th*math.log(.05))})
csvsave('theta_sensitivity.csv',thresholds)
# Force-profile sensitivity; dimensionless area=1, peak=.5+1/delta.
def profile(u,d):return .5+(1/d)*(1-abs(2*u/d-1)) if 0<=u<=d else .5
work=[]
for d in [1,.5,.25,.1]:
 area=quad(lambda u:profile(u,d),0,1,points=[d/2,d])[0];peak=profile(d/2,d)
 assert abs(area-1)<1e-12 and abs(peak-(.5+1/d))<1e-12
 work.append({'delta':d,'normalized_work':area,'normalized_peak':peak})
csvsave('work_peak.csv',work)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
f,ax=plt.subplots(figsize=(7,3))
u=np.linspace(0,1,2001);ax.plot(u,np.ones_like(u),'--',color='#89929e',label='Constant')
for d,c in [(1,'#c896a3'),(.5,'#a34a60'),(.25,'#75182e')]:ax.plot(u,[profile(v,d) for v in u],color=c,label=f'delta={d:g}')
ax.set(xlabel='Normalized displacement x/L',ylabel='Normalized force LF/W',ylim=(0,5));ax.legend(frameon=False,ncol=2,fontsize=8)
f.tight_layout();f.savefig(R/'work_peak.png',dpi=220);plt.close(f)
f,axs=plt.subplots(1,2,figsize=(7,3))
for label,c in zip([v['model'] for v in robust],['#222a36','#c896a3','#a34a60','#75182e']):
 rows=[v for v in grids if v['model']==label]
 axs[0].plot([v['r'] for v in rows],[max(v['false_A'],v['false_B']) for v in rows],label=label,color=c)
axs[0].axhline(.05,color='#777777',ls='--',lw=.8);axs[0].set(xlabel='Independent contrasting blocks r',ylabel='Larger of two error probabilities',ylim=(0,.4),xlim=(1,60));axs[0].legend(frameon=False,fontsize=7)
xx=np.arange(4);axs[1].bar(xx-.17,[v['mu_C'] for v in interactions],.34,color='#831b32',label='C: cycle + time');axs[1].bar(xx+.17,[v['mu_D'] for v in interactions],.34,color='#a2a8b3',label='D: cycle + interaction')
axs[1].set(xticks=xx,xticklabels=['1,1','1,3','2,1','2,3'],xlabel='Normalized exposures x,z',ylabel='Expected events');axs[1].legend(frameon=False,fontsize=7)
f.tight_layout();f.savefig(R/'robustness_interaction.png',dpi=220);plt.close(f)
# Independent exact minimum-exposure and likelihood sanity checks.
assert math.ceil(-5000*math.log(.05))==14979
assert abs(math.exp(-10000/(10000/-math.log(.05)))-.05)<1e-12
for r in [1,5,10,20]:
 h=rule(r,None)
 assert poisson.logpmf(h,4*r)-poisson.logpmf(h,2*r)>0
 assert poisson.logpmf(h-1,4*r)-poisson.logpmf(h-1,2*r)<0
emit('Checks passed: quadrature; weighted-Gram identity; rank; likelihood thresholds; tail recurrences; renewal inversion')
emit('All outputs are model-conditional synthetic calculations, not measured carrier performance.')
(R/'execution_log.txt').write_text('\n'.join(log)+'\n')
summary={'version':'1.2','seed':SEED,'draws_per_batch':M,'total_synthetic_total_count_draws':8*M,'robustness':robust,'interaction_fixed_cycle_means_C':(feat(fixed)@C).tolist(),'interaction_fixed_cycle_means_D':(feat(fixed)@D).tolist(),'interaction_factorial_rank':3,'renewal':renew,'work':work,'max_mc_standardized_deviation':max(abs(v[k]) for v in robust for k in ['mc_false_A_standardized_deviation','mc_false_B_standardized_deviation']),'hardware_data':False,'field_validation':False}
(R/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
